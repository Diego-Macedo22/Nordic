-- Nordic 0.5.0. GENERATED: edit new migrations, never this file directly.
-- First install only. Do not use --force. Future upgrades: npm run migrate.
CREATE DATABASE IF NOT EXISTS nordic_v05 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nordic_v05;
SET time_zone = '+00:00';
CREATE TABLE IF NOT EXISTS schema_migrations (
  version VARCHAR(100) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  checksum CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  status ENUM('applying','applied') NOT NULL,
  started_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  applied_at DATETIME(3) NULL
) ENGINE=InnoDB;

INSERT INTO schema_migrations(version,checksum,status) VALUES ('001_schema.sql','2ff5e58b0430696d4523233408a2012c47f5717487ce98b3ecc924f9877c1815','applying');
-- Nordic database 0.5.0. MySQL 8.4. UTC. Do not edit an applied migration.

CREATE TABLE accounts (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(24) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL,
 password_hash VARCHAR(255) CHARACTER SET ascii NOT NULL,
 display_name VARCHAR(48) NOT NULL,
 status ENUM('active','blocked','deleted') NOT NULL DEFAULT 'active',
 created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
 UNIQUE KEY uq_accounts_username (username),
 CONSTRAINT ck_username_length CHECK (CHAR_LENGTH(username) BETWEEN 3 AND 24)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE sessions (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 account_id BIGINT UNSIGNED NOT NULL,
 token_hash BINARY(32) NOT NULL,
 created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 expires_at DATETIME(3) NOT NULL,
 revoked_at DATETIME(3) NULL,
 UNIQUE KEY uq_sessions_token (token_hash),
 KEY ix_sessions_expiry (expires_at),
 FOREIGN KEY (account_id) REFERENCES accounts(id),
 CHECK (expires_at > created_at)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE worlds (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 name VARCHAR(80) NOT NULL,
 owner_account_id BIGINT UNSIGNED NOT NULL,
 width_km SMALLINT UNSIGNED NOT NULL DEFAULT 260,
 height_km SMALLINT UNSIGNED NOT NULL DEFAULT 180,
 territory_km SMALLINT UNSIGNED NOT NULL DEFAULT 25,
 rules_version VARCHAR(20) NOT NULL DEFAULT '0.5.0',
 settings JSON NOT NULL,
 editing_enabled BOOLEAN NOT NULL DEFAULT FALSE,
 status ENUM('open','closed','archived') NOT NULL DEFAULT 'open',
 created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 UNIQUE KEY uq_world_code (code),
 FOREIGN KEY (owner_account_id) REFERENCES accounts(id),
 CHECK (width_km >= territory_km AND height_km >= territory_km AND territory_km > 0)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE world_members (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 world_id BIGINT UNSIGNED NOT NULL,
 account_id BIGINT UNSIGNED NOT NULL,
 joined_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 start_sector ENUM('north','south','east','west','center') NOT NULL,
 victories BIGINT UNSIGNED NOT NULL DEFAULT 0,
 defeats BIGINT UNSIGNED NOT NULL DEFAULT 0,
 UNIQUE KEY uq_world_account (world_id,account_id),
 UNIQUE KEY uq_member_world (id,world_id),
 FOREIGN KEY (world_id) REFERENCES worlds(id),
 FOREIGN KEY (account_id) REFERENCES accounts(id)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE resource_types (
code VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 name VARCHAR(40) NOT NULL,
 tradeable BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE building_types (
code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 name VARCHAR(64) NOT NULL,
 max_level SMALLINT UNSIGNED NULL,
 starting_level SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 base_wood DECIMAL(20,4) NOT NULL,
 base_clay DECIMAL(20,4) NOT NULL,
 base_iron DECIMAL(20,4) NOT NULL,
 base_seconds INT UNSIGNED NOT NULL,
 production_resource VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NULL,
 production_per_second DECIMAL(14,6) NOT NULL DEFAULT 0,
 level_zero_production DECIMAL(14,6) NOT NULL DEFAULT 0,
 FOREIGN KEY (production_resource) REFERENCES resource_types(code),
 CHECK (max_level IS NULL OR max_level >= starting_level),
 CHECK (base_wood>=0 AND base_clay>=0 AND base_iron>=0 AND production_per_second>=0 AND level_zero_production>=0)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE building_requirements (
building_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 required_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 required_level SMALLINT UNSIGNED NOT NULL,
 PRIMARY KEY (building_code,required_code),
 FOREIGN KEY (building_code) REFERENCES building_types(code),
 FOREIGN KEY (required_code) REFERENCES building_types(code),
 CHECK (building_code <> required_code AND required_level>0)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE unit_types (
code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
 name VARCHAR(64) NOT NULL,
 combat_role ENUM('attack','defense','both') NOT NULL,
 training_building VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 building_unlock_level SMALLINT UNSIGNED NOT NULL DEFAULT 1,
 initially_unlocked BOOLEAN NOT NULL DEFAULT FALSE,
 attack DECIMAL(12,4) NOT NULL,
 defense DECIMAL(12,4) NOT NULL,
 hitpoints INT UNSIGNED NOT NULL,
 population SMALLINT UNSIGNED NOT NULL,
 training_seconds INT UNSIGNED NOT NULL,
 wood_cost DECIMAL(20,4) NOT NULL,
 clay_cost DECIMAL(20,4) NOT NULL,
 iron_cost DECIMAL(20,4) NOT NULL,
 FOREIGN KEY (training_building) REFERENCES building_types(code),
 CHECK (attack>=0 AND defense>=0 AND hitpoints>0 AND population>0 AND training_seconds>0),
 CHECK (wood_cost>=0 AND clay_cost>=0 AND iron_cost>=0)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE research_tiers (
tier TINYINT UNSIGNED PRIMARY KEY,
 tavern_level SMALLINT UNSIGNED NOT NULL,
 barracks_level SMALLINT UNSIGNED NOT NULL,
 specialized_level SMALLINT UNSIGNED NOT NULL,
 combat_bonus DECIMAL(8,4) NOT NULL,
 cost_multiplier DECIMAL(10,4) NOT NULL,
 time_multiplier DECIMAL(10,4) NOT NULL,
 CHECK (tier BETWEEN 1 AND 3 AND combat_bonus>=0 AND cost_multiplier>0 AND time_multiplier>0)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE npc_templates (
id SMALLINT UNSIGNED PRIMARY KEY,
 name VARCHAR(80) NOT NULL,
 x_km DECIMAL(7,2) NOT NULL,
 y_km DECIMAL(7,2) NOT NULL,
 difficulty SMALLINT UNSIGNED NOT NULL,
 resources JSON NOT NULL,
 buildings JSON NOT NULL,
 troops JSON NOT NULL,
 towers JSON NOT NULL,
 CHECK (x_km>=0 AND y_km>=0 AND difficulty>0)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE villages (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 world_id BIGINT UNSIGNED NOT NULL,
 owner_member_id BIGINT UNSIGNED NULL,
 primary_member_id BIGINT UNSIGNED NULL,
 npc_template_id SMALLINT UNSIGNED NULL,
 name VARCHAR(80) NOT NULL,
 x_km DECIMAL(7,2) NOT NULL,
 y_km DECIMAL(7,2) NOT NULL,
 difficulty SMALLINT UNSIGNED NOT NULL DEFAULT 1,
 state_version BIGINT UNSIGNED NOT NULL DEFAULT 0,
 last_economy_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 UNIQUE KEY uq_village_world (id,world_id),
 UNIQUE KEY uq_village_position (world_id,x_km,y_km),
 UNIQUE KEY uq_primary_village (primary_member_id),
 KEY ix_village_owner (owner_member_id,world_id),
 FOREIGN KEY (world_id) REFERENCES worlds(id),
 FOREIGN KEY (owner_member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (primary_member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (npc_template_id) REFERENCES npc_templates(id),
 CHECK (x_km>=0 AND y_km>=0),
 CHECK (primary_member_id IS NULL OR (owner_member_id IS NOT NULL AND primary_member_id=owner_member_id))
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE village_resources (
village_id BIGINT UNSIGNED NOT NULL,
 resource_code VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 amount DECIMAL(20,4) NOT NULL DEFAULT 0,
 reserved_incoming DECIMAL(20,4) NOT NULL DEFAULT 0,
 PRIMARY KEY (village_id,resource_code),
 FOREIGN KEY (village_id) REFERENCES villages(id),
 FOREIGN KEY (resource_code) REFERENCES resource_types(code),
 CHECK (amount>=0 AND reserved_incoming>=0)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE village_buildings (
village_id BIGINT UNSIGNED NOT NULL,
 building_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 level SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 reconstruction_levels SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 PRIMARY KEY (village_id,building_code),
 FOREIGN KEY (village_id) REFERENCES villages(id),
 FOREIGN KEY (building_code) REFERENCES building_types(code),
 CHECK (building_code <> 'tavern' OR level<=20)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE village_towers (
village_id BIGINT UNSIGNED NOT NULL,
 corner TINYINT UNSIGNED NOT NULL,
 level TINYINT UNSIGNED NOT NULL DEFAULT 0,
 PRIMARY KEY (village_id,corner),
 FOREIGN KEY (village_id) REFERENCES villages(id),
 CHECK (corner BETWEEN 1 AND 4 AND level<=5)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE village_troops (
village_id BIGINT UNSIGNED NOT NULL,
 unit_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 quantity BIGINT UNSIGNED NOT NULL DEFAULT 0,
 PRIMARY KEY (village_id,unit_code),
 FOREIGN KEY (village_id) REFERENCES villages(id),
 FOREIGN KEY (unit_code) REFERENCES unit_types(code)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE village_research (
village_id BIGINT UNSIGNED NOT NULL,
 unit_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 unlocked BOOLEAN NOT NULL DEFAULT FALSE,
 improvement_level TINYINT UNSIGNED NOT NULL DEFAULT 0,
 PRIMARY KEY (village_id,unit_code),
 FOREIGN KEY (village_id) REFERENCES villages(id),
 FOREIGN KEY (unit_code) REFERENCES unit_types(code),
 CHECK (improvement_level<=3 AND (unlocked=TRUE OR improvement_level=0))
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE construction_queue (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 village_id BIGINT UNSIGNED NOT NULL,
 building_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 tower_corner TINYINT UNSIGNED NULL,
 target_level SMALLINT UNSIGNED NOT NULL,
 starts_at DATETIME(3) NOT NULL,
 ends_at DATETIME(3) NOT NULL,
 status ENUM('queued','completed','cancelled') NOT NULL DEFAULT 'queued',
 paid_cost JSON NOT NULL,
 active_village_id BIGINT UNSIGNED GENERATED ALWAYS AS (CASE WHEN status='queued' THEN village_id ELSE NULL END) STORED,
 UNIQUE KEY uq_active_construction (active_village_id),
 KEY ix_construction_due (status,ends_at),
 FOREIGN KEY (village_id) REFERENCES villages(id),
 FOREIGN KEY (building_code) REFERENCES building_types(code),
 CHECK (ends_at>=starts_at AND target_level>0),
 CHECK ((building_code IS NOT NULL AND tower_corner IS NULL) OR (building_code IS NULL AND tower_corner IS NOT NULL AND tower_corner BETWEEN 1 AND 4)),
 CHECK (tower_corner IS NULL OR target_level<=5),
 CHECK (building_code IS NULL OR building_code<>'tavern' OR target_level<=20)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE training_queue (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 village_id BIGINT UNSIGNED NOT NULL,
 unit_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 starts_at DATETIME(3) NOT NULL,
 ends_at DATETIME(3) NOT NULL,
 status ENUM('queued','completed','cancelled') NOT NULL DEFAULT 'queued',
 paid_cost JSON NOT NULL,
 KEY ix_training_due (status,ends_at,id),
 KEY ix_training_village (village_id,status,ends_at,id),
 FOREIGN KEY (village_id) REFERENCES villages(id),
 FOREIGN KEY (unit_code) REFERENCES unit_types(code),
 CHECK (ends_at>starts_at)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE research_queue (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 village_id BIGINT UNSIGNED NOT NULL,
 unit_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 kind ENUM('unlock','improve') NOT NULL,
 target_level TINYINT UNSIGNED NOT NULL DEFAULT 0,
 starts_at DATETIME(3) NOT NULL,
 ends_at DATETIME(3) NOT NULL,
 status ENUM('queued','completed','cancelled') NOT NULL DEFAULT 'queued',
 paid_cost JSON NOT NULL,
 active_village_id BIGINT UNSIGNED GENERATED ALWAYS AS (CASE WHEN status='queued' THEN village_id ELSE NULL END) STORED,
 UNIQUE KEY uq_active_research (active_village_id),
 KEY ix_research_due (status,ends_at),
 FOREIGN KEY (village_id) REFERENCES villages(id),
 FOREIGN KEY (unit_code) REFERENCES unit_types(code),
 CHECK (ends_at>starts_at),
 CHECK ((kind='unlock' AND target_level=0) OR (kind='improve' AND target_level BETWEEN 1 AND 3))
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE movements (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 world_id BIGINT UNSIGNED NOT NULL,
 actor_member_id BIGINT UNSIGNED NOT NULL,
 origin_village_id BIGINT UNSIGNED NOT NULL,
 destination_village_id BIGINT UNSIGNED NOT NULL,
 parent_movement_id BIGINT UNSIGNED NULL,
 kind ENUM('attack','transport','return') NOT NULL,
 target_building VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NULL,
 status ENUM('travelling','waiting_capacity','completed','cancelled') NOT NULL DEFAULT 'travelling',
 departed_at DATETIME(3) NOT NULL,
 arrives_at DATETIME(3) NOT NULL,
 processed_at DATETIME(3) NULL,
 combat_snapshot JSON NULL,
 reserved_population BIGINT UNSIGNED NOT NULL DEFAULT 0,
 UNIQUE KEY uq_movement_world (id,world_id),
 UNIQUE KEY uq_return_parent (parent_movement_id),
 KEY ix_movement_due (status,arrives_at,id),
 FOREIGN KEY (world_id) REFERENCES worlds(id),
 FOREIGN KEY (actor_member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (origin_village_id,world_id) REFERENCES villages(id,world_id),
 FOREIGN KEY (destination_village_id,world_id) REFERENCES villages(id,world_id),
 FOREIGN KEY (parent_movement_id,world_id) REFERENCES movements(id,world_id),
 FOREIGN KEY (target_building) REFERENCES building_types(code),
 CHECK (origin_village_id<>destination_village_id AND arrives_at>=departed_at),
 CHECK ((kind='return' AND parent_movement_id IS NOT NULL) OR (kind<>'return' AND parent_movement_id IS NULL)),
 CHECK (target_building IS NULL OR kind='attack')
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE movement_troops (
movement_id BIGINT UNSIGNED NOT NULL,
 unit_code VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 quantity BIGINT UNSIGNED NOT NULL,
 CHECK (quantity>0),
 PRIMARY KEY (movement_id,unit_code),
 FOREIGN KEY (movement_id) REFERENCES movements(id),
 FOREIGN KEY (unit_code) REFERENCES unit_types(code)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE movement_resources (
movement_id BIGINT UNSIGNED NOT NULL,
 resource_code VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 amount DECIMAL(20,4) NOT NULL,
 CHECK (amount>0),
 PRIMARY KEY (movement_id,resource_code),
 FOREIGN KEY (movement_id) REFERENCES movements(id),
 FOREIGN KEY (resource_code) REFERENCES resource_types(code)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE market_offers (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 world_id BIGINT UNSIGNED NOT NULL,
 seller_member_id BIGINT UNSIGNED NOT NULL,
 seller_village_id BIGINT UNSIGNED NOT NULL,
 status ENUM('open','accepted','cancelled','expired') NOT NULL DEFAULT 'open',
 created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 expires_at DATETIME(3) NULL,
 closed_at DATETIME(3) NULL,
 UNIQUE KEY uq_offer_world (id,world_id),
 KEY ix_market_open (world_id,status,created_at),
 FOREIGN KEY (world_id) REFERENCES worlds(id),
 FOREIGN KEY (seller_member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (seller_village_id,world_id) REFERENCES villages(id,world_id),
 CHECK (expires_at IS NULL OR expires_at>created_at)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE market_offer_items (
offer_id BIGINT UNSIGNED NOT NULL,
 side ENUM('give','want') NOT NULL,
 resource_code VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 amount DECIMAL(20,4) NOT NULL,
 PRIMARY KEY (offer_id,side,resource_code),
 FOREIGN KEY (offer_id) REFERENCES market_offers(id),
 FOREIGN KEY (resource_code) REFERENCES resource_types(code),
 CHECK (amount>0 AND resource_code<>'food')
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE market_trades (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 world_id BIGINT UNSIGNED NOT NULL,
 offer_id BIGINT UNSIGNED NOT NULL,
 buyer_member_id BIGINT UNSIGNED NOT NULL,
 buyer_village_id BIGINT UNSIGNED NOT NULL,
 items_snapshot JSON NOT NULL,
 created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 UNIQUE KEY uq_trade_offer (offer_id),
 FOREIGN KEY (offer_id,world_id) REFERENCES market_offers(id,world_id),
 FOREIGN KEY (buyer_member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (buyer_village_id,world_id) REFERENCES villages(id,world_id)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE battles (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 world_id BIGINT UNSIGNED NOT NULL,
 movement_id BIGINT UNSIGNED NOT NULL,
 attacker_member_id BIGINT UNSIGNED NOT NULL,
 defender_member_id BIGINT UNSIGNED NULL,
 destination_village_id BIGINT UNSIGNED NOT NULL,
 result ENUM('victory','defeat','wall_held','cancelled') NOT NULL,
 conquered BOOLEAN NOT NULL DEFAULT FALSE,
 wall_before SMALLINT UNSIGNED NOT NULL,
 wall_after SMALLINT UNSIGNED NOT NULL,
 attack_power DECIMAL(24,4) NOT NULL,
 defense_power DECIMAL(24,4) NOT NULL,
 report JSON NOT NULL,
 resolved_at DATETIME(3) NOT NULL,
 UNIQUE KEY uq_battle_movement (movement_id),
 UNIQUE KEY uq_battle_world (id,world_id),
 KEY ix_battle_attacker (attacker_member_id,resolved_at),
 KEY ix_battle_defender (defender_member_id,resolved_at),
 FOREIGN KEY (movement_id,world_id) REFERENCES movements(id,world_id),
 FOREIGN KEY (attacker_member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (defender_member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (destination_village_id,world_id) REFERENCES villages(id,world_id),
 CHECK (attack_power>=0 AND defense_power>=0 AND wall_after<=wall_before),
 CHECK (conquered=FALSE OR (result='victory' AND wall_after=0))
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE ownership_history (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 world_id BIGINT UNSIGNED NOT NULL,
 village_id BIGINT UNSIGNED NOT NULL,
 previous_member_id BIGINT UNSIGNED NULL,
 new_member_id BIGINT UNSIGNED NOT NULL,
 battle_id BIGINT UNSIGNED NOT NULL,
 changed_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 UNIQUE KEY uq_ownership_battle (battle_id),
 FOREIGN KEY (village_id,world_id) REFERENCES villages(id,world_id),
 FOREIGN KEY (previous_member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (new_member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (battle_id,world_id) REFERENCES battles(id,world_id)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE relocations (
member_id BIGINT UNSIGNED PRIMARY KEY,
 world_id BIGINT UNSIGNED NOT NULL,
 village_id BIGINT UNSIGNED NOT NULL,
 old_x DECIMAL(7,2) NOT NULL,
 old_y DECIMAL(7,2) NOT NULL,
 new_x DECIMAL(7,2) NOT NULL,
 new_y DECIMAL(7,2) NOT NULL,
 sector ENUM('north','south','east','west','center') NOT NULL,
 relocated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 FOREIGN KEY (member_id,world_id) REFERENCES world_members(id,world_id),
 FOREIGN KEY (village_id,world_id) REFERENCES villages(id,world_id)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE resource_ledger (
id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 village_id BIGINT UNSIGNED NOT NULL,
 resource_code VARCHAR(16) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 delta DECIMAL(20,4) NOT NULL,
 balance_after DECIMAL(20,4) NOT NULL,
 reason VARCHAR(40) CHARACTER SET ascii NOT NULL,
 event_key VARCHAR(100) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 UNIQUE KEY uq_resource_event (village_id,resource_code,event_key),
 KEY ix_ledger_village (village_id,created_at),
 FOREIGN KEY (village_id) REFERENCES villages(id),
 FOREIGN KEY (resource_code) REFERENCES resource_types(code),
 CHECK (balance_after>=0)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE village_statistics (
village_id BIGINT UNSIGNED PRIMARY KEY,
 statistics JSON NOT NULL,
 FOREIGN KEY (village_id) REFERENCES villages(id)
) ENGINE=InnoDB;

-- statement-breakpoint

CREATE TABLE processed_commands (
member_id BIGINT UNSIGNED NOT NULL,
 request_key VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
 command VARCHAR(40) CHARACTER SET ascii NOT NULL,
 request_hash BINARY(32) NOT NULL,
 result JSON NOT NULL,
 created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
 PRIMARY KEY (member_id,request_key),
 FOREIGN KEY (member_id) REFERENCES world_members(id)
) ENGINE=InnoDB;

UPDATE schema_migrations SET status='applied',applied_at=UTC_TIMESTAMP(3) WHERE version='001_schema.sql';

INSERT INTO schema_migrations(version,checksum,status) VALUES ('002_catalogs.sql','cd3470936485d31cea6abed161354ad432cd01b6b4144e365d3d7c3c126d28b1','applying');
-- Catalogs match Nordic v0.5 codes. Lanceiro HP 120 implements defensive-role health.

INSERT INTO resource_types (code,name,tradeable) VALUES
('wood','Madeira',1),
('clay','Argila',1),
('iron','Ferro',1),
('food','Comida',0);

-- statement-breakpoint

INSERT INTO building_types (code,name,max_level,starting_level,base_wood,base_clay,base_iron,base_seconds,production_resource,production_per_second,level_zero_production) VALUES
('main','Salão da Vila',NULL,1,90,80,70,60,NULL,0,0),
('wood','Bosque de Pinheiros',NULL,0,50,60,40,40,'wood',4.5,0.54),
('clay','Pedreira do Fiorde',NULL,0,65,50,40,40,'clay',3.5,0.525),
('iron','Forja de Ferro',NULL,0,75,65,70,45,'iron',1.2,0),
('store','Armazém',NULL,0,60,50,40,35,NULL,0,0),
('farm','Casas Longas',NULL,0,45,40,30,30,NULL,0,0),
('meat','Casa de Carne',NULL,0,150,120,90,65,'food',0.085,0),
('barracks','Salão dos Guerreiros',NULL,0,200,170,90,80,NULL,0,0),
('tavern','Taberna',20,0,1400,1100,900,240,NULL,0,0),
('wall','Muralha',NULL,0,250,200,110,120,NULL,0,0),
('stable','Estábulo',NULL,0,950,650,1200,190,NULL,0,0),
('workshop','Oficina',NULL,0,1700,1500,1350,240,NULL,0,0),
('market','Mercado',NULL,0,700,650,500,140,NULL,0,0);

-- statement-breakpoint

INSERT INTO building_requirements (building_code,required_code,required_level) VALUES
('stable','main',10),
('stable','tavern',5),
('stable','barracks',10),
('workshop','main',15),
('workshop','tavern',10),
('workshop','barracks',15),
('market','main',5),
('market','store',5);

-- statement-breakpoint

INSERT INTO unit_types (code,name,combat_role,training_building,building_unlock_level,initially_unlocked,attack,defense,hitpoints,population,training_seconds,wood_cost,clay_cost,iron_cost) VALUES
('spear','Lanceiro','defense','barracks',1,1,10,15,120,1,20,50,30,10),
('sword','Berserker','attack','barracks',1,1,25,10,100,1,30,30,30,70),
('spy','Espião','defense','barracks',1,0,3,18,120,1,35,90,55,80),
('swordsman','Espadachim','defense','barracks',1,0,12,27,135,1,40,70,75,110),
('archer','Arqueiro','defense','barracks',1,0,14,23,110,1,38,100,55,75),
('catapult','Catapulta','attack','workshop',2,0,140,6,90,5,180,260,350,180),
('ram','Aríete','attack','workshop',2,0,100,9,130,6,210,370,450,200),
('lightCavalry','Cavalaria Leve','both','stable',2,0,48,42,130,3,95,200,160,270),
('heavyCavalry','Cavalaria Pesada','both','stable',2,0,82,75,170,5,160,330,310,470);

-- statement-breakpoint

INSERT INTO research_tiers (tier,tavern_level,barracks_level,specialized_level,combat_bonus,cost_multiplier,time_multiplier) VALUES
(1,3,5,2,0.12,4,5),
(2,8,10,5,0.24,16,25),
(3,15,15,10,0.36,64,125);

-- statement-breakpoint

INSERT INTO npc_templates (id,name,x_km,y_km,difficulty,resources,buildings,troops,towers) VALUES
(1,'Vila do Norte',35.0,65.0,3,'{"wood": 600, "clay": 500, "iron": 350, "food": 1000}','{"main": 3, "wood": 2, "clay": 3, "iron": 1, "store": 3, "farm": 3, "meat": 3, "barracks": 1, "tavern": 1, "wall": 1, "stable": 0, "workshop": 0, "market": 0}','{"spear": 16, "sword": 2, "catapult": 0}','[0, 0, 0, 0]'),
(2,'Vila do Leste',90.0,82.0,4,'{"wood": 900, "clay": 700, "iron": 600, "food": 1000}','{"main": 4, "wood": 3, "clay": 4, "iron": 2, "store": 3, "farm": 4, "meat": 4, "barracks": 2, "tavern": 2, "wall": 2, "stable": 0, "workshop": 0, "market": 0}','{"spear": 15, "sword": 5, "catapult": 0}','[0, 0, 0, 0]'),
(3,'Vila do Sul',52.0,115.0,5,'{"wood": 1200, "clay": 950, "iron": 750, "food": 1000}','{"main": 5, "wood": 4, "clay": 5, "iron": 3, "store": 4, "farm": 5, "meat": 5, "barracks": 3, "tavern": 2, "wall": 2, "stable": 0, "workshop": 0, "market": 0}','{"spear": 30, "sword": 8, "catapult": 0}','[0, 0, 0, 0]'),
(4,'Vila dos Corvos',18.0,108.0,7,'{"wood": 1800, "clay": 1400, "iron": 900, "food": 1000}','{"main": 7, "wood": 6, "clay": 7, "iron": 5, "store": 6, "farm": 7, "meat": 7, "barracks": 5, "tavern": 3, "wall": 3, "stable": 0, "workshop": 0, "market": 0}','{"spear": 48, "sword": 15, "catapult": 0}','[0, 0, 0, 0]'),
(5,'Vila da Névoa',51.0,37.0,8,'{"wood": 2400, "clay": 1800, "iron": 1200, "food": 1000}','{"main": 8, "wood": 7, "clay": 8, "iron": 6, "store": 7, "farm": 8, "meat": 8, "barracks": 10, "tavern": 4, "wall": 4, "stable": 0, "workshop": 0, "market": 3}','{"spear": 65, "sword": 25, "catapult": 2}','[0, 0, 0, 0]'),
(6,'Vila dos Carvalhos',88.0,127.0,9,'{"wood": 2900, "clay": 2200, "iron": 1500, "food": 1000}','{"main": 9, "wood": 8, "clay": 9, "iron": 7, "store": 8, "farm": 9, "meat": 9, "barracks": 10, "tavern": 4, "wall": 5, "stable": 0, "workshop": 0, "market": 4}','{"spear": 85, "sword": 35, "catapult": 4}','[0, 0, 0, 0]'),
(7,'Vila do Machado',21.0,144.0,11,'{"wood": 3600, "clay": 2800, "iron": 1900, "food": 1000}','{"main": 11, "wood": 10, "clay": 11, "iron": 9, "store": 10, "farm": 11, "meat": 11, "barracks": 10, "tavern": 5, "wall": 7, "stable": 0, "workshop": 0, "market": 6}','{"spear": 120, "sword": 55, "catapult": 8}','[0, 0, 0, 0]'),
(8,'Vila da Aurora',88.0,19.0,13,'{"wood": 4500, "clay": 3500, "iron": 2300, "food": 1000}','{"main": 13, "wood": 12, "clay": 13, "iron": 11, "store": 12, "farm": 13, "meat": 13, "barracks": 11, "tavern": 6, "wall": 9, "stable": 4, "workshop": 0, "market": 8}','{"spear": 160, "sword": 85, "catapult": 12}','[0, 0, 0, 0]'),
(9,'Vila do Estreito',145.0,85.0,15,'{"wood": 5400, "clay": 4500, "iron": 2800, "food": 1000}','{"main": 15, "wood": 14, "clay": 15, "iron": 13, "store": 14, "farm": 15, "meat": 15, "barracks": 13, "tavern": 7, "wall": 12, "stable": 6, "workshop": 0, "market": 10}','{"spear": 200, "sword": 120, "catapult": 20}','[0, 0, 0, 0]'),
(10,'Vila da Geada',153.0,36.0,17,'{"wood": 6500, "clay": 5800, "iron": 3300, "food": 1000}','{"main": 17, "wood": 16, "clay": 17, "iron": 15, "store": 16, "farm": 17, "meat": 17, "barracks": 15, "tavern": 8, "wall": 14, "stable": 8, "workshop": 3, "market": 12}','{"spear": 260, "sword": 170, "catapult": 30}','[0, 0, 0, 0]'),
(11,'Vila do Urso',172.0,138.0,20,'{"wood": 7600, "clay": 7400, "iron": 4000, "food": 1000}','{"main": 20, "wood": 19, "clay": 20, "iron": 18, "store": 19, "farm": 20, "meat": 20, "barracks": 18, "tavern": 10, "wall": 16, "stable": 11, "workshop": 6, "market": 15}','{"spear": 330, "sword": 240, "catapult": 45}','[1, 1, 1, 1]'),
(12,'Vila do Trovão',209.0,94.0,23,'{"wood": 9000, "clay": 10000, "iron": 5000, "food": 1000}','{"main": 23, "wood": 22, "clay": 23, "iron": 21, "store": 22, "farm": 23, "meat": 23, "barracks": 21, "tavern": 11, "wall": 18, "stable": 14, "workshop": 9, "market": 18}','{"spear": 410, "sword": 350, "catapult": 70}','[1, 1, 1, 1]'),
(13,'Vila de Valhalla',237.0,24.0,25,'{"wood": 10000, "clay": 14000, "iron": 6000, "food": 1000}','{"main": 25, "wood": 24, "clay": 25, "iron": 23, "store": 24, "farm": 25, "meat": 25, "barracks": 23, "tavern": 12, "wall": 20, "stable": 16, "workshop": 11, "market": 20}','{"spear": 500, "sword": 500, "catapult": 100}','[1, 1, 1, 1]');

UPDATE schema_migrations SET status='applied',applied_at=UTC_TIMESTAMP(3) WHERE version='002_catalogs.sql';

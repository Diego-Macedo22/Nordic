# Nordic — banco de dados 0.5.0

Este pacote define o banco MySQL para as funcionalidades atuais do Nordic v0.5.
Contém 31 tabelas de domínio, uma tabela de controle de migrações, os catálogos
de 13 construções e 9 tropas e os modelos das 13 aldeias NPC.

**Este pacote cria a estrutura do banco. A integração do index.html com as APIs
no server.js é uma etapa separada.** O HTML atual ainda usa localStorage.
O banco não executa sozinho produção, treinos, ataques ou movimentações.

## 1. Instalar pela primeira vez

Requisitos: MySQL 8.4 ou superior. Para usar as migrações automáticas: Node.js 22
ou superior e npm. MariaDB não foi validado.

Extraia o ZIP e abra um terminal **dentro da pasta Nordic-Database-v0.5**.
O banco criado chama-se **nordic_v05**, para não sobrescrever o laboratório
anterior chamado `nordic`.

Escolha **uma** das duas opções abaixo.

### Opção A — importar o SQL pelo terminal

Execute no terminal do Linux, na pasta do projeto:

```bash
mysql -u root -p < schema.sql
```

Digite a senha do seu MySQL. Nenhuma mensagem de erro normalmente significa
que a importação terminou. Para conferir:

```bash
mysql -u root -p nordic_v05
```

Quando aparecer o prompt `mysql>`, execute apenas estes comandos SQL:

```sql
SHOW TABLES;
SELECT version, status, applied_at FROM schema_migrations;
SELECT code, name FROM building_types;
SELECT name, x_km, y_km FROM npc_templates ORDER BY id;
```

Você verá duas migrações com status `applied`, 13 construções e 13 modelos de
aldeias. `exit` fecha o cliente MySQL. Não digite comandos `CREATE TABLE` no
terminal normal do Linux: eles devem ser executados dentro do MySQL ou por
meio da importação acima.

Se o MySQL do seu Linux autentica root pelo sistema, substitua o comando de
importação por `sudo mysql < schema.sql`.

### Opção B — instalar e atualizar com Node.js

No terminal normal:

```bash
cp .env.example .env
npm install
```

Abra `.env` no editor e preencha o usuário e a senha do seu MySQL. Depois:

```bash
npm run migrate
```

O instalador cria o banco e aplica as migrações em ordem. Rodar novamente não
reaplica as versões concluídas. Ele também detecta arquivos antigos alterados
ou uma instalação interrompida. Use um usuário com permissão de criar o banco
na primeira instalação; em hospedagem que já fornece um banco vazio, configure
`DB_NAME` com o nome fornecido e use a opção B.

Não execute novamente `schema.sql` para atualizar um banco em uso. Ele é
somente a instalação inicial. Depois, use `npm run migrate`.

## 2. O que está incluído

| Área | Dados guardados |
|---|---|
| Contas | Nick único sem distinguir maiúsculas, hash da senha, sessões com expiração |
| Mundos | Código, proprietário, configuração de regras, tamanho 260 × 180 km |
| Participação | Conta em cada mundo, data de entrada, região inicial, vitórias e derrotas |
| Aldeias | Dono, aldeia principal, coordenadas, NPC de origem e versão do estado |
| Economia | Madeira, argila, ferro e comida, reservas de transporte, histórico de transações |
| Construções | Níveis, níveis que precisam de reconstrução, pré-requisitos e quatro torres |
| Tropas | Nove tipos, tropas na aldeia, tropas viajando e treino de uma unidade por linha |
| Pesquisa | Desbloqueios, três melhorias e fila da Taberna |
| Mercado | Vários recursos de oferta/pagamento, oferta reservada e registro da negociação |
| Movimento | Ataques, transporte e retorno, horário de chegada e alvo das catapultas |
| Combate | Resultado, muralha antes/depois, perdas, danos, saque e conquista |
| Localização | Histórico da mudança, limitada a uma por participante |
| Atualizações | Arquivos numerados e verificação de integridade das migrações |

Nenhuma conta real é criada. Não há senhas prontas. Os NPCs são **modelos**;
quando o servidor criar um mundo, deverá gerar as aldeias daquele mundo a
partir de `npc_templates`.

## 3. Arquivos

- `schema.sql`: instalação inicial completa, gerada a partir das migrações.
- `migrations/001_schema.sql`: estrutura e restrições.
- `migrations/002_catalogs.sql`: construções, requisitos, tropas, pesquisas e NPCs.
- `scripts/migrate.mjs`: instalador de migrações.
- `docs/MODELO.md`: tabelas, relações, fórmulas e correspondência com o HTML.
- `docs/INTEGRACAO.md`: operações que o servidor precisa implementar.
- `docs/MIGRACOES.md`: procedimento para futuras mudanças e recuperação de falhas.
- `docs/CONSULTAS.sql`: consultas de inspeção, sem modificar dados.
- `test/`: verificações do pacote e testes opcionais em MySQL.

## 4. Como me enviar futuramente

Guarde este ZIP e a pasta do projeto no GitHub. Quando precisar de mudanças,
envie a pasta compactada contendo `migrations`, `scripts`, `docs`,
`schema.sql`, `package.json` e, depois do npm install, `package-lock.json`.
Envie também o `server.js` e o `index.html` que estiver realmente usando.
Diga quais funcionalidades deseja mudar e informe o resultado de:

```sql
SELECT version, checksum, status FROM schema_migrations ORDER BY version;
```

A próxima alteração deverá ser um arquivo novo, por exemplo
`003_nova_funcionalidade.sql`. Assim, o progresso existente é preservado.
Não inclua `.env`, senhas, tokens, `node_modules` nem dados pessoais de jogadores.
Não é preciso enviar todos os dados do banco para mudar sua estrutura.

## 5. Backup antes de atualizar

No terminal, antes de uma migração em um banco com jogadores:

```bash
mysqldump -u root -p --single-transaction --no-tablespaces nordic_v05 > backup-nordic.sql
```

Guarde esse arquivo fora do repositório público. Teste a restauração em outro
banco antes de depender do backup. Não importe um backup em cima da produção
sem revisar seu conteúdo.

## 6. Verificação

```bash
npm run check
```

Isso verifica a estrutura do pacote e a consistência do SQL gerado, sem abrir
uma conexão MySQL. Para executar os testes reais do banco, crie `.env.test`
a partir de `.env.example`, use **DB_NAME=nordic_v05_test**, instale as
dependências e execute:

```bash
npm run test:mysql
```

O teste recusa nomes que não terminam em `_test`. Ele instala o schema nesse
banco e testa restrições dentro de uma transação revertida no final.

Validação nesta entrega: sintaxe JavaScript e verificações estáticas passaram.
Não havia um servidor MySQL disponível no ambiente de edição; a importação e
os testes reais precisam ser executados no seu MySQL.

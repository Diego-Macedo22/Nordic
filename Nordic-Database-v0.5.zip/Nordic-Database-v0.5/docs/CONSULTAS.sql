-- Execute depois de selecionar seu banco: USE nordic_v05;
SELECT version,status,applied_at FROM schema_migrations ORDER BY version;
SELECT code,name FROM building_types ORDER BY code;
SELECT code,name,combat_role,population FROM unit_types ORDER BY code;
SELECT name,x_km,y_km,difficulty FROM npc_templates ORDER BY id;
SELECT w.code,v.name,v.x_km,v.y_km,a.username
FROM villages v JOIN worlds w ON w.id=v.world_id
LEFT JOIN world_members m ON m.id=v.owner_member_id
LEFT JOIN accounts a ON a.id=m.account_id ORDER BY w.id,v.id;
SELECT id,world_id,status,created_at FROM market_offers ORDER BY id DESC LIMIT 50;
SELECT id,kind,status,arrives_at FROM movements WHERE status IN ('travelling','waiting_capacity') ORDER BY arrives_at;
SELECT COUNT(*) AS tables_count FROM information_schema.tables WHERE table_schema=DATABASE();

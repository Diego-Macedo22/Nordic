# Modelo Nordic 0.5.0

## Convenções

- MySQL 8.4, InnoDB e UTF-8; horários DATETIME(3) em UTC.
- IDs BIGINT UNSIGNED devem ser recebidos no Node como string para evitar perda
  de precisão. DECIMAL também deve ser tratado como decimal; não arredondar saldos
  repetidamente a cada atualização do navegador.
- Nick global é ASCII e não diferencia maiúsculas. Nome visual aceita Unicode.
- Os códigos internos do HTML foram mantidos. `sword` é Berserker e `swordsman`
  é Espadachim. `clay` continua sendo argila, mesmo quando a interface usa pedra.
- Recursos: quatro tipos; comida não é negociável no mercado desta versão.
- IDs numéricos das aldeias NPC do HTML correspondem a npc_templates.id; cada
  mundo recebe villages.id próprios. `home` do HTML é primary_member_id do membro.
- Uma aldeia conquistada muda de owner_member_id, preservando seu id e seus
  recursos/níveis após dano. Se a aldeia era principal, limpar primary_member_id
  antes de trocar o dono. A política de uma nova principal é do servidor.

## Tabelas

| Tabela | Função |
|---|---|
| schema_migrations | Versão, SHA-256 e status de cada migração |
| accounts | Cadastro e hash de senha |
| sessions | Hash de token, validade e revogação |
| worlds | Mundo, proprietário e configurações |
| world_members | Participação de uma conta em um mundo |
| resource_types | Madeira, argila, ferro e comida |
| building_types | Nomes, custos, tempos e produção base |
| building_requirements | Pré-requisitos de cada construção |
| unit_types | Função, força, vida, população, custo e local de treino |
| research_tiers | Requisitos e bônus dos três níveis de melhoria |
| npc_templates | Modelos das 13 aldeias NPC, sem dono ou progresso real |
| villages | Coordenadas, dono, principal e versão do estado |
| village_resources | Saldos e reservas de recursos recebidos |
| village_buildings | Nível e quantidade de níveis a reconstruir |
| village_towers | Níveis das quatro torres de cada aldeia |
| village_troops | Tropas presentes em cada aldeia |
| village_research | Desbloqueios e níveis de melhoria locais |
| construction_queue | Uma obra ou torre pendente por aldeia |
| training_queue | Uma linha por tropa treinada, em ordem de conclusão |
| research_queue | Uma pesquisa pendente por aldeia |
| movements | Viagens de ataque, transporte ou retorno |
| movement_troops | Tropas de cada viagem |
| movement_resources | Recursos de cada viagem |
| market_offers | Proposta e situação da oferta |
| market_offer_items | Um ou mais itens oferecidos e pedidos |
| market_trades | Compra concluída, uma por oferta |
| battles | Uma resolução por movimento de ataque |
| ownership_history | Histórico de conquista |
| relocations | Uma mudança de local por participante |
| resource_ledger | Auditoria de débitos/créditos e resultado após evento |
| village_statistics | Estatísticas detalhadas da aldeia |
| processed_commands | Idempotência de pedidos do cliente |

## Relações principais

Conta 1:N participação; mundo 1:N participação; participação 1:N aldeia;
aldeia 1:N recursos/construções/tropas/filas. Uma conta pode jogar em vários
mundos e governar várias aldeias em cada mundo. NPCs têm dono NULL.
As FKs compostas com world_id impedem ligar um movimento, oferta, combate ou
aldeia a um participante de outro mundo.

## Correspondência com o HTML atual

| Campo atual | Destino |
|---|---|
| S.res e S.food | village_resources, códigos wood/clay/iron/food |
| S.buildings | village_buildings |
| S.rebuildDebt | village_buildings.reconstruction_levels |
| S.towers[0..3] | village_towers.corner 1..4 |
| S.troops | village_troops |
| S.trainQueue | training_queue |
| S.buildQueue | construction_queue |
| S.research | village_research |
| S.researchQueue | research_queue |
| S.attacks / S.shipments | movements e tabelas filhas |
| S.reports | battles.report |
| S.ownedVillages | villages filtradas por owner_member_id |
| S.joinedAt | world_members.joined_at |
| S.homePos | villages.x_km/y_km, convertendo pixels /10 |
| S.relocated | existência de relocations para o membro |
| S.stats | village_statistics e contadores world_members |
| ofertas localStorage | market_offers, market_offer_items, market_trades |

## Fórmulas e decisões

`config/default-world.json` contém o conjunto inicial para worlds.settings.
O catálogo fornece a base; alterações por mundo ficam no JSON de configurações.
Campos ausentes devem usar o valor padrão da versão das regras do mundo.

- Produção de recurso no nível L>=1: base × growth^(L−1) por segundo.
- Nível zero: madeira 0,54/s, argila 0,525/s, ferro e comida zero.
- Madeira, argila e ferro têm taxas base diferentes, mas a progressão por nível
  usa a mesma fórmula. Capacidade limita ganho e não modifica a taxa base.
- Moradia: round(200 × 1,28^nível_casas + 45 × (nível_salão−1)). Início: 200.
- Armazém por recurso: round(1000 × 1,5^(nível_salão + nível_armazém−2)).
  Essa fórmula preserva o HTML: no início, Salão 1 e Armazém 0 dão 667 por recurso.
- Comida máxima: duas vezes capacidade do Armazém. Suporte: floor(comida/5).
- Taberna: 2,5 pontos de felicidade por nível, até 50 pontos no nível 20.
- Felicidade: limitar a 100 o total de comida (até 40), moradia (até 35),
  histórico (25 se vitórias >=75%, senão round(taxa×20)) e Taberna.
  Sem batalhas, considerar taxa de vitórias zero.
- Bônus de felicidade em combate: se felicidade>=60, felicidade/100×0,5;
  abaixo de 60, zero. A aplicação de velocidade/ataque deve seguir a versão
  de regras escolhida, usando snapshots do momento de envio.
- Custo de construção: base × 1,26^nível atual, arredondado. Reconstrução: 1,6×
  enquanto houver reconstruction_levels; reduzir esse contador só ao concluir
  o nível restaurado. Cancelamento não elimina a dívida de reconstrução.
- Melhoria de tropa: níveis 1/2/3 concedem +12/+24/+36% sobre a base,
  sem composição entre níveis. Requisitos são registrados em research_tiers.
- Lanceiro tem HP 120 para atender à categoria defensiva; o HTML entregue antes
  usava implicitamente 100. Ao integrar, usar este catálogo como fonte única.
- Pré-requisitos especializados: Estábulo exige Salão 10, Taberna 5, Quartel 10;
  Oficina exige 15/10/15; Mercado exige Salão 5 e Armazém 5.
- Torres: construir apenas com Muralha>=15, níveis 1 a 5 em quatro posições.
- Unidades especializadas exigem construção nível 2 para pesquisa inicial,
  conforme v0.5. Elas não começam desbloqueadas.

Não guardar felicidade ou capacidade como números independentes que possam
ficar desatualizados: calcular a partir das fontes acima. reserved_incoming é
uma reserva transacional, não um segundo saldo. Para população recebida, somar
reserved_population dos movimentos pendentes para o destino.

## Formato dos JSONs

- worlds.settings: objeto de config/default-world.json, com eventuais ajustes.
- npc_templates.resources/buildings/troops: objeto código→quantidade/nível.
- npc_templates.towers: array de quatro níveis.
- paid_cost: objeto wood/clay/iron com valores efetivamente debitados.
- combat_snapshot: bônus, pesquisa, regras e valores de unidade no envio.
- battles.report: tropas enviadas, perdas dos dois lados, sobreviventes, saque,
  danos por código de construção, origem/destino, regras e mensagens.
- market_trades.items_snapshot: objetos give e want com quantidades negociadas.
- village_statistics.statistics: contadores históricos do HTML, sem saldo atual.
- processed_commands.result: resposta JSON já enviada para aquele pedido.

O servidor deve validar formatos e limites desses objetos antes de gravar.

# Alterações futuras sem apagar o progresso

## Regra principal

Depois que uma migração foi aplicada, seu conteúdo não deve mudar. Para qualquer
alteração, acrescente um arquivo com o próximo número: `003_...sql`, `004_...sql`.
O arquivo deve conter SQL MySQL e separar cada comando completo por uma linha:

```sql
-- statement-breakpoint
```

O instalador calcula SHA-256 de cada arquivo e compara com `schema_migrations`.
Essa verificação impede que uma versão antiga seja trocada silenciosamente.

## Procedimento

1. Fazer backup e testar numa cópia do banco.
2. Escrever a nova migração com ALTER TABLE/INSERT/UPDATE necessários.
3. Alterar o servidor e a interface para utilizar os novos campos.
4. Rodar `npm run check`, depois os testes MySQL e `npm run migrate` na cópia.
5. Regenerar `schema.sql` com `npm run build:sql` para instalações novas.
6. Fazer commit de migração, servidor e interface; publicar a mudança.
7. Aplicar a migração em produção antes de ativar o código que depende dela.

Campos novos usados por código antigo devem começar com valor padrão ou permitir
NULL. Para renomear/remover dados em produção, prefira etapas compatíveis: adicionar,
preencher, mudar o código e só então remover numa migração posterior.

## Instalação interrompida

MySQL faz commits implícitos para várias instruções DDL como CREATE TABLE e
ALTER TABLE. Uma migração com vários comandos não é revertida inteira com
ROLLBACK. Por isso o instalador registra `applying` antes de começar e só marca
`applied` depois do último comando. Se falhar, ele interrompe novas execuções.

Não mude manualmente o status para `applied` sem conferir todos os comandos.
Em banco com dados, examine a falha, compare o schema real com o arquivo e
complete cuidadosamente a operação ou restaure o backup. Uma migração corretiva
só deve seguir depois de resolver a versão interrompida. Em instalação nova e
vazia, recrie apenas o banco novo após confirmar que não há dados importantes.

Não use `mysql --force`: isso pode continuar após erros e registrar uma instalação
incompleta como concluída. Não rode SQL manual e o migrador Node ao mesmo tempo.
O migrador Node usa GET_LOCK para impedir duas execuções simultâneas dele mesmo.

Fontes oficiais consultadas:
- https://dev.mysql.com/doc/refman/8.4/en/implicit-commit.html
- https://dev.mysql.com/doc/refman/8.4/en/create-table-check-constraints.html
- https://dev.mysql.com/doc/refman/8.4/en/create-table-foreign-keys.html

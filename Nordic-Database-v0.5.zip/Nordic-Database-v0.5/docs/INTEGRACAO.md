# Contrato para integrar Node.js, HTML e MySQL

O banco fornece persistência e restrições. O servidor precisa receber intenções
como “treinar 10 lanceiros”, validar a conta e executar a operação. Não crie uma
API que aceite e sobrescreva todo o estado enviado pelo navegador: isso permitiria
alterar recursos, tropas e propriedade de aldeias.

Todas as consultas com dados de usuário devem usar parâmetros `?`. As credenciais
ficam no `.env` do servidor. O aplicativo não deve conectar como root: use um
usuário com SELECT, INSERT, UPDATE e DELETE apenas no banco do jogo. Use um usuário
administrador separado para migrações. Configure TLS com verificação de certificado
quando o provedor do banco exigir conexão remota segura.

## Contas e sessão

- Cadastro: validar nick com `^[A-Za-z0-9_]{3,24}$`; UNIQUE de accounts.username
  rejeita repetições e também Axel/axel. display_name é apenas visual.
- Senhas: produzir hash com scrypt/Argon2id, salt aleatório e parâmetros dentro de
  password_hash. Não gravar senha pura, SHA simples ou hash calculado no HTML.
- Login: verificar hash; gerar token aleatório forte, armazenar apenas SHA-256
  do token em sessions.token_hash; enviar o token por cookie HttpOnly, Secure em
  HTTPS e SameSite. Autorizar toda rota a partir da sessão.
- Logout: preencher revoked_at. Conferir expires_at em cada acesso.

## Transações e repetição de pedidos

Adquirir bloqueios em ordem estável: mundo, aldeias em ordem de id e depois filas,
ofertas e movimentos. Para cada POST usar uma request_key e hash dos parâmetros.
Registrar processed_commands na mesma transação da ação. Repetir a chave com o
mesmo hash devolve o resultado anterior; com conteúdo diferente, rejeitar.
A sessão determina o member_id: não confiar em um ID enviado pelo navegador.

O worker usa SELECT ... FOR UPDATE e status para concluir cada evento uma vez.
As chaves UNIQUE em battles.movement_id, market_trades.offer_id e no registro de
comandos protegem contra processamento duplicado. Ainda são necessárias transações;
UNIQUE por si só não impede que o débito seja feito duas vezes.

## Operações de API previstas

| Rota proposta | Operação |
|---|---|
| POST /api/accounts | Cadastro com nick e senha |
| POST /api/sessions | Login |
| DELETE /api/sessions/current | Logout |
| POST /api/worlds | Criar mundo e aldeia inicial |
| POST /api/worlds/:code/join | Entrar ou recuperar participação existente |
| GET /api/worlds/:code/map | NPCs, jogadores, donos e coordenadas |
| GET /api/villages/:id | Estado autorizado da aldeia |
| POST /api/villages/:id/build | Melhorar/construir |
| POST /api/villages/:id/train | Enfileirar unidades individuais |
| POST /api/villages/:id/research | Desbloquear ou melhorar tropa |
| POST /api/villages/:id/relocate | Usar a mudança única de região |
| POST /api/market/offers | Reservar recursos e publicar oferta |
| POST /api/market/offers/:id/accept | Pagar e concluir troca |
| POST /api/market/offers/:id/cancel | Devolver recursos reservados |
| POST /api/movements | Enviar ataque ou transporte |
| GET /api/battles | Relatórios acessíveis ao jogador |

Estas rotas são o contrato de implementação; não existe servidor HTTP neste pacote.

## Criar mundo e entrar

1. Transação: inserir worlds com settings padrão descritas em MODELO.md.
2. Materializar cada npc_templates em villages e suas tabelas de recursos,
   construções, tropas, torres e pesquisas. Não compartilhar saldos entre mundos.
3. Inserir world_members (UNIQUE world/account). Ao entrar novamente, recuperar
   o membro existente e suas aldeias; não reiniciar seu progresso.
4. Bloquear a linha worlds com FOR UPDATE antes de escolher uma posição. O lock
   deve ser usado por TODO caminho que cria ou muda coordenadas.
5. Encontrar posição em terra firme no setor escolhido, dentro dos limites,
   sem sobreposição dos quadrados 25 × 25 km. Para dois centros a e b, existe
   sobreposição se abs(a.x-b.x)<25 E abs(a.y-b.y)<25. Terreno navegável e limites
   do setor vêm do mapa do servidor. UNIQUE de coordenadas exatas não garante
   sozinho a distância entre territórios.
6. Inserir villages com owner_member_id=primary_member_id=membro. Criar todas as
   linhas de construção com starting_level, quatro torres no nível 0, tropas
   zeradas, pesquisas iniciais conforme catálogo e recursos 500/500/500/1000.
7. Persistir joined_at e confirmar a transação.

Os centros NPC seguem a tabela recebida, incluindo Norte (35,65). O centro
histórico da Principal (55,85) fica a 20 km em cada eixo do Norte; portanto os
quadrados de 25 km se sobrepõem nesse caso. Para novas aldeias, deve prevalecer
uma posição livre do setor, em vez de forçar (55,85). Não usar automaticamente as
posições do HTML como prova de terreno livre.

## Produção e filas

Bloquear a aldeia, calcular a produção desde last_economy_at e processar eventos
cronologicamente. Uma melhoria concluída no meio do intervalo muda a taxa a
partir da sua conclusão, não retroativamente. Registrar custo no momento da
compra, horários UTC e as regras relevantes para não alterar uma fila quando
houver rebalanceamento. Treinar 100 unidades cria 100 linhas training_queue,
com starts_at de cada uma igual ao ends_at anterior. Apenas uma construção e
uma pesquisa pendentes por aldeia; os índices gerados também impõem esse limite.

Moradia considera tropas em casa, tropas reservadas em treino e tropas próprias
viajando. Reservar também a população das caravanas de chegada. Comida e moradia
são verificadas juntas para recrutar/receber novas tropas.

## Mercado

Ofertas são indivisíveis nesta versão. Debitar todos os itens give ao publicar;
esses valores passam a ser a reserva da oferta e não podem continuar no saldo
livre. Inserir ao menos um give e um want, com números positivos e três recursos
negociáveis. Aceitar bloqueia oferta e ambas as aldeias: conferir mundo, donos,
Mercado, saldo do comprador e capacidade dos dois destinos; debitar pagamento,
creditar os dois lados e inserir market_trades. Atualizar status na mesma transação.
Cancelar/expirar devolve a reserva uma única vez. Se não houver espaço, manter a
oferta reservada até haver capacidade; nunca descartar recursos silenciosamente.
Conquista deve cancelar/devolver ou liquidar ofertas pendentes antes de trocar
seu proprietário, com uma política explícita de devolução.

## Transporte e ataque

Transporte: conferir que ambas as aldeias pertencem ao jogador; bloquear origem
e destino, atualizar produção, conferir capacidade incluindo outras chegadas,
debitar a origem e reservar o destino. Salvar recursos/tropas em movement_*.
Na chegada, revalidar capacidade e propriedade; entregar uma vez e liberar
reservas. Se cheio, manter waiting_capacity; se o destino mudou de dono,
criar retorno sem perder recursos e liberar reservas do destino anterior.

Ataque: gravar as tropas enviadas e uma cópia dos bônus/pesquisas relevantes em
combat_snapshot. Não confiar no ataque/defesa calculado pelo HTML. Primeiro resolver
cerco; só permitir conquista com muralha zero e tropas defensoras derrotadas.
Persistir dano direcionado e reconstruction_levels, report com perdas/danos/saque,
estatísticas e ownership_history na mesma transação. Tropas sobreviventes passam
para a guarnição conquistada ou para um movimento de retorno. Invalidar filas,
reservas e comandos do dono anterior conforme política definida de conquista.

## Relocação

Bloquear mundo, membro e aldeia principal. Conferir joined_at + 7 dias e ausência
de relocations. Validar território livre, atualizar x/y e inserir relocations na
mesma transação. A chave primária member_id impede um segundo uso. Manter os
horários já calculados de movimentos existentes; não recalcular uma viagem no
meio dela por causa da mudança.

## Limites da camada SQL

FKs garantem referências e pertencimento ao mesmo mundo. CHECKs garantem valores
não negativos, três melhorias, Taberna <=20, torres <=5 e conquista com muralha
zero. Autorização, território livre, sete dias, capacidade, preços, produção,
pré-requisitos, sequência de treino e coerência dos relatórios exigem validação
transacional no servidor. JSON é usado em configurações, snapshots e relatórios;
os saldos, proprietários, tropas e níveis correntes ficam em tabelas relacionais.

## Migração do laboratório e do localStorage

Este pacote usa um banco novo. Ele NÃO importa automaticamente o antigo nordic
nem os perfis locais. Para migrar progresso, criar um importador que autentique o
dono, valide recursos/níveis, mapeie as chaves descritas em MODELO.md, resolva
coordenadas conflitantes e registre a importação uma única vez. Conserve uma cópia
do localStorage antes de qualquer teste; nunca permita importação arbitrária de
salvamentos em um mundo competitivo público.

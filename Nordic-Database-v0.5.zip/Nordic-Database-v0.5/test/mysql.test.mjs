// Integração opcional. Nunca executa contra o banco de produção.
import assert from 'node:assert/strict';
import mysql from 'mysql2/promise';
import {migrate} from '../scripts/migrate.mjs';
import {connectionOptions,databaseName} from '../scripts/common.mjs';
const db=databaseName();if(!db.endsWith('_test'))throw new Error('DB_NAME deve terminar em _test.');
await migrate();await migrate();
const conn=await mysql.createConnection({...await connectionOptions(),database:db});
const failWith=async(sql,params,code)=>assert.rejects(conn.execute(sql,params),e=>e.code===code);
try{
 await conn.beginTransaction();
 const tag='t'+Date.now();
 const [a]=await conn.execute('INSERT INTO accounts(username,password_hash,display_name) VALUES (?,?,?)',[tag,'TEST_ONLY_NOT_A_LOGIN_HASH','Teste']);
 await failWith('INSERT INTO accounts(username,password_hash,display_name) VALUES (?,?,?)',[tag.toUpperCase(),'x','Teste'],'ER_DUP_ENTRY');
 const [w]=await conn.execute('INSERT INTO worlds(code,name,owner_account_id,settings) VALUES (?,?,?,?)',[tag,'Teste',a.insertId,'{}']);
 const [w2]=await conn.execute('INSERT INTO worlds(code,name,owner_account_id,settings) VALUES (?,?,?,?)',[tag+'x','Outro',a.insertId,'{}']);
 const [m]=await conn.execute("INSERT INTO world_members(world_id,account_id,start_sector) VALUES (?,?,'south')",[w.insertId,a.insertId]);
 const [v]=await conn.execute('INSERT INTO villages(world_id,owner_member_id,primary_member_id,name,x_km,y_km) VALUES (?,?,?,?,?,?)',[w.insertId,m.insertId,m.insertId,'Teste',30,120]);
 await failWith('INSERT INTO villages(world_id,owner_member_id,name,x_km,y_km) VALUES (?,?,?,?,?)',[w2.insertId,m.insertId,'Outro',40,100],'ER_NO_REFERENCED_ROW_2');
 await failWith("INSERT INTO village_resources(village_id,resource_code,amount) VALUES (?,'wood',-1)",[v.insertId],'ER_CHECK_CONSTRAINT_VIOLATED');
 await failWith("INSERT INTO village_buildings(village_id,building_code,level) VALUES (?,'tavern',21)",[v.insertId],'ER_CHECK_CONSTRAINT_VIOLATED');
 await failWith("INSERT INTO village_research(village_id,unit_code,unlocked,improvement_level) VALUES (?,'spear',1,4)",[v.insertId],'ER_CHECK_CONSTRAINT_VIOLATED');
 const build="INSERT INTO construction_queue(village_id,building_code,target_level,starts_at,ends_at,paid_cost) VALUES (?,'main',2,UTC_TIMESTAMP(3),DATE_ADD(UTC_TIMESTAMP(3),INTERVAL 60 SECOND),'{}')";
 await conn.execute(build,[v.insertId]);await failWith(build,[v.insertId],'ER_DUP_ENTRY');
 await failWith("INSERT INTO construction_queue(village_id,target_level,starts_at,ends_at,paid_cost,status) VALUES (?,1,UTC_TIMESTAMP(3),UTC_TIMESTAMP(3),'{}','completed')",[v.insertId],'ER_CHECK_CONSTRAINT_VIOLATED');
 const [[count]]=await conn.query('SELECT COUNT(*) AS n FROM npc_templates');assert.equal(Number(count.n),13);
 console.log('MySQL: migração repetida, FKs, unicidade e CHECKs verificados.');
}finally{await conn.rollback();await conn.end();}

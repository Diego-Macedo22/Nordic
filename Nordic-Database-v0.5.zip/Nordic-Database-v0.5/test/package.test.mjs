import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {root,migrationFiles} from '../scripts/common.mjs';
test('schema gerado contém as migrações atuais e seus hashes',async()=>{
 const schema=await readFile(new URL('schema.sql',root),'utf8');
 for(const file of await migrationFiles()){assert(schema.includes(file.sql));assert(schema.includes(file.checksum));assert(file.statements.length>0);}
});
test('todas as tabelas referenciadas existem e não há DROP no instalador',async()=>{
 const files=await migrationFiles(),sql=files.map(f=>f.sql).join('\n');
 const names=new Set([...sql.matchAll(/CREATE TABLE (\w+)/g)].map(m=>m[1]));
 assert.equal(names.size,31);for(const match of sql.matchAll(/REFERENCES (\w+)\(/g))assert(names.has(match[1]),match[1]);
 assert(!/\bDROP\s+(TABLE|DATABASE)\b/i.test(sql));assert(sql.includes('uq_battle_movement'));assert(sql.includes('uq_trade_offer'));
});
test('pacote inclui catálogos e defaults necessários para v0.5',async()=>{
 const sql=await readFile(new URL('migrations/002_catalogs.sql',root),'utf8');
 for(const code of ['spear','sword','spy','swordsman','archer','catapult','ram','lightCavalry','heavyCavalry'])assert(sql.includes("('"+code+"'"));
 for(const code of ['stable','workshop','market','tavern'])assert(sql.includes("('"+code+"'"));
 assert(sql.includes('Vila de Valhalla'));assert(sql.includes('Vila do Norte'));
 const rules=JSON.parse(await readFile(new URL('config/default-world.json',root),'utf8'));assert.equal(rules.farmBase,200);assert.equal(rules.widthKm,260);assert.equal(rules.tavernMaxLevel*rules.tavernHappinessPerLevel,50);
});

-- Catalogs match Nordic v0.5 codes. Lanceiro HP 120 implements defensive-role health.

INSERT INTO resource_types (code,name,tradeable) VALUES
('wood','Madeira',1),
('clay','Argila',1),
('iron','Ferro',1),
('food','Comida',0);

-- statement-breakpoint

INSERT INTO building_types (code,name,max_level,starting_level,base_wood,base_clay,base_iron,base_seconds,production_resource,production_per_second,level_zero_production) VALUES
('main','Salão da Vila',NULL,1,90,80,70,60,NULL,0,0),
('wood','Bosque de Pinheiros',NULL,0,50,60,40,40,'wood',4.5,0.54),
('clay','Pedreira do Fiorde',NULL,0,65,50,40,40,'clay',3.5,0.525),
('iron','Forja de Ferro',NULL,0,75,65,70,45,'iron',1.2,0),
('store','Armazém',NULL,0,60,50,40,35,NULL,0,0),
('farm','Casas Longas',NULL,0,45,40,30,30,NULL,0,0),
('meat','Casa de Carne',NULL,0,150,120,90,65,'food',0.085,0),
('barracks','Salão dos Guerreiros',NULL,0,200,170,90,80,NULL,0,0),
('tavern','Taberna',20,0,1400,1100,900,240,NULL,0,0),
('wall','Muralha',NULL,0,250,200,110,120,NULL,0,0),
('stable','Estábulo',NULL,0,950,650,1200,190,NULL,0,0),
('workshop','Oficina',NULL,0,1700,1500,1350,240,NULL,0,0),
('market','Mercado',NULL,0,700,650,500,140,NULL,0,0);

-- statement-breakpoint

INSERT INTO building_requirements (building_code,required_code,required_level) VALUES
('stable','main',10),
('stable','tavern',5),
('stable','barracks',10),
('workshop','main',15),
('workshop','tavern',10),
('workshop','barracks',15),
('market','main',5),
('market','store',5);

-- statement-breakpoint

INSERT INTO unit_types (code,name,combat_role,training_building,building_unlock_level,initially_unlocked,attack,defense,hitpoints,population,training_seconds,wood_cost,clay_cost,iron_cost) VALUES
('spear','Lanceiro','defense','barracks',1,1,10,15,120,1,20,50,30,10),
('sword','Berserker','attack','barracks',1,1,25,10,100,1,30,30,30,70),
('spy','Espião','defense','barracks',1,0,3,18,120,1,35,90,55,80),
('swordsman','Espadachim','defense','barracks',1,0,12,27,135,1,40,70,75,110),
('archer','Arqueiro','defense','barracks',1,0,14,23,110,1,38,100,55,75),
('catapult','Catapulta','attack','workshop',2,0,140,6,90,5,180,260,350,180),
('ram','Aríete','attack','workshop',2,0,100,9,130,6,210,370,450,200),
('lightCavalry','Cavalaria Leve','both','stable',2,0,48,42,130,3,95,200,160,270),
('heavyCavalry','Cavalaria Pesada','both','stable',2,0,82,75,170,5,160,330,310,470);

-- statement-breakpoint

INSERT INTO research_tiers (tier,tavern_level,barracks_level,specialized_level,combat_bonus,cost_multiplier,time_multiplier) VALUES
(1,3,5,2,0.12,4,5),
(2,8,10,5,0.24,16,25),
(3,15,15,10,0.36,64,125);

-- statement-breakpoint

INSERT INTO npc_templates (id,name,x_km,y_km,difficulty,resources,buildings,troops,towers) VALUES
(1,'Vila do Norte',35.0,65.0,3,'{"wood": 600, "clay": 500, "iron": 350, "food": 1000}','{"main": 3, "wood": 2, "clay": 3, "iron": 1, "store": 3, "farm": 3, "meat": 3, "barracks": 1, "tavern": 1, "wall": 1, "stable": 0, "workshop": 0, "market": 0}','{"spear": 16, "sword": 2, "catapult": 0}','[0, 0, 0, 0]'),
(2,'Vila do Leste',90.0,82.0,4,'{"wood": 900, "clay": 700, "iron": 600, "food": 1000}','{"main": 4, "wood": 3, "clay": 4, "iron": 2, "store": 3, "farm": 4, "meat": 4, "barracks": 2, "tavern": 2, "wall": 2, "stable": 0, "workshop": 0, "market": 0}','{"spear": 15, "sword": 5, "catapult": 0}','[0, 0, 0, 0]'),
(3,'Vila do Sul',52.0,115.0,5,'{"wood": 1200, "clay": 950, "iron": 750, "food": 1000}','{"main": 5, "wood": 4, "clay": 5, "iron": 3, "store": 4, "farm": 5, "meat": 5, "barracks": 3, "tavern": 2, "wall": 2, "stable": 0, "workshop": 0, "market": 0}','{"spear": 30, "sword": 8, "catapult": 0}','[0, 0, 0, 0]'),
(4,'Vila dos Corvos',18.0,108.0,7,'{"wood": 1800, "clay": 1400, "iron": 900, "food": 1000}','{"main": 7, "wood": 6, "clay": 7, "iron": 5, "store": 6, "farm": 7, "meat": 7, "barracks": 5, "tavern": 3, "wall": 3, "stable": 0, "workshop": 0, "market": 0}','{"spear": 48, "sword": 15, "catapult": 0}','[0, 0, 0, 0]'),
(5,'Vila da Névoa',51.0,37.0,8,'{"wood": 2400, "clay": 1800, "iron": 1200, "food": 1000}','{"main": 8, "wood": 7, "clay": 8, "iron": 6, "store": 7, "farm": 8, "meat": 8, "barracks": 10, "tavern": 4, "wall": 4, "stable": 0, "workshop": 0, "market": 3}','{"spear": 65, "sword": 25, "catapult": 2}','[0, 0, 0, 0]'),
(6,'Vila dos Carvalhos',88.0,127.0,9,'{"wood": 2900, "clay": 2200, "iron": 1500, "food": 1000}','{"main": 9, "wood": 8, "clay": 9, "iron": 7, "store": 8, "farm": 9, "meat": 9, "barracks": 10, "tavern": 4, "wall": 5, "stable": 0, "workshop": 0, "market": 4}','{"spear": 85, "sword": 35, "catapult": 4}','[0, 0, 0, 0]'),
(7,'Vila do Machado',21.0,144.0,11,'{"wood": 3600, "clay": 2800, "iron": 1900, "food": 1000}','{"main": 11, "wood": 10, "clay": 11, "iron": 9, "store": 10, "farm": 11, "meat": 11, "barracks": 10, "tavern": 5, "wall": 7, "stable": 0, "workshop": 0, "market": 6}','{"spear": 120, "sword": 55, "catapult": 8}','[0, 0, 0, 0]'),
(8,'Vila da Aurora',88.0,19.0,13,'{"wood": 4500, "clay": 3500, "iron": 2300, "food": 1000}','{"main": 13, "wood": 12, "clay": 13, "iron": 11, "store": 12, "farm": 13, "meat": 13, "barracks": 11, "tavern": 6, "wall": 9, "stable": 4, "workshop": 0, "market": 8}','{"spear": 160, "sword": 85, "catapult": 12}','[0, 0, 0, 0]'),
(9,'Vila do Estreito',145.0,85.0,15,'{"wood": 5400, "clay": 4500, "iron": 2800, "food": 1000}','{"main": 15, "wood": 14, "clay": 15, "iron": 13, "store": 14, "farm": 15, "meat": 15, "barracks": 13, "tavern": 7, "wall": 12, "stable": 6, "workshop": 0, "market": 10}','{"spear": 200, "sword": 120, "catapult": 20}','[0, 0, 0, 0]'),
(10,'Vila da Geada',153.0,36.0,17,'{"wood": 6500, "clay": 5800, "iron": 3300, "food": 1000}','{"main": 17, "wood": 16, "clay": 17, "iron": 15, "store": 16, "farm": 17, "meat": 17, "barracks": 15, "tavern": 8, "wall": 14, "stable": 8, "workshop": 3, "market": 12}','{"spear": 260, "sword": 170, "catapult": 30}','[0, 0, 0, 0]'),
(11,'Vila do Urso',172.0,138.0,20,'{"wood": 7600, "clay": 7400, "iron": 4000, "food": 1000}','{"main": 20, "wood": 19, "clay": 20, "iron": 18, "store": 19, "farm": 20, "meat": 20, "barracks": 18, "tavern": 10, "wall": 16, "stable": 11, "workshop": 6, "market": 15}','{"spear": 330, "sword": 240, "catapult": 45}','[1, 1, 1, 1]'),
(12,'Vila do Trovão',209.0,94.0,23,'{"wood": 9000, "clay": 10000, "iron": 5000, "food": 1000}','{"main": 23, "wood": 22, "clay": 23, "iron": 21, "store": 22, "farm": 23, "meat": 23, "barracks": 21, "tavern": 11, "wall": 18, "stable": 14, "workshop": 9, "market": 18}','{"spear": 410, "sword": 350, "catapult": 70}','[1, 1, 1, 1]'),
(13,'Vila de Valhalla',237.0,24.0,25,'{"wood": 10000, "clay": 14000, "iron": 6000, "food": 1000}','{"main": 25, "wood": 24, "clay": 25, "iron": 23, "store": 24, "farm": 25, "meat": 25, "barracks": 23, "tavern": 12, "wall": 20, "stable": 16, "workshop": 11, "market": 20}','{"spear": 500, "sword": 500, "catapult": 100}','[1, 1, 1, 1]');

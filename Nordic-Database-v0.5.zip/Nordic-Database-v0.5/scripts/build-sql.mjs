import { writeFile } from 'node:fs/promises';
import { root,metadataSQL,migrationFiles } from './common.mjs';
let sql=`-- Nordic 0.5.0. GENERATED: edit new migrations, never this file directly.
-- First install only. Do not use --force. Future upgrades: npm run migrate.
CREATE DATABASE IF NOT EXISTS nordic_v05 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nordic_v05;
SET time_zone = '+00:00';
${metadataSQL};\n`;
for(const f of await migrationFiles())sql+=`\nINSERT INTO schema_migrations(version,checksum,status) VALUES ('${f.name}','${f.checksum}','applying');\n${f.sql}\nUPDATE schema_migrations SET status='applied',applied_at=UTC_TIMESTAMP(3) WHERE version='${f.name}';\n`;
await writeFile(new URL('schema.sql',root),sql);console.log('schema.sql gerado.');

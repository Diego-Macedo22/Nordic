import mysql from 'mysql2/promise';
import { pathToFileURL } from 'node:url';
import { metadataSQL,migrationFiles,connectionOptions,databaseName } from './common.mjs';
export async function migrate(){
 const name=databaseName(), conn=await mysql.createConnection(await connectionOptions());let locked=false;
 try{
  const [[version]]=await conn.query('SELECT VERSION() AS version');
  if(/mariadb/i.test(version.version)||parseInt(version.version)<8)throw new Error('Este projeto requer MySQL 8.4 ou superior; MariaDB não foi validado.');
  const [major,minor]=version.version.split('.').map(Number);if(major===8&&minor<4)throw new Error('Use MySQL 8.4 ou superior para este pacote.');
  await conn.query("SET time_zone = '+00:00'");
  const [[lock]]=await conn.execute('SELECT GET_LOCK(?,10) AS acquired',['nordic_migrate_'+name]);
  if(Number(lock.acquired)!==1)throw new Error('Outra migração está em execução.');locked=true;
  try { await conn.query(`USE \`${name}\``); } catch (error) {
   if(error.code!=='ER_BAD_DB_ERROR')throw error;
   await conn.query(`CREATE DATABASE \`${name}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
   await conn.query(`USE \`${name}\``);
  }
  await conn.query(metadataSQL);
  const [applied]=await conn.query('SELECT * FROM schema_migrations');const files=await migrationFiles();
  for(const row of applied){const file=files.find(f=>f.name===row.version);if(!file||row.checksum!==file.checksum)throw new Error('Histórico incompatível: '+row.version+'. Não altere migrações já aplicadas.');if(row.status!=='applied')throw new Error('Migração incompleta: '+row.version+'. Leia docs/MIGRACOES.md antes de continuar.');}
  for(const file of files){if(applied.some(a=>a.version===file.name)){console.log('Já aplicado: '+file.name);continue;}
   await conn.execute("INSERT INTO schema_migrations(version,checksum,status) VALUES (?,?,'applying')",[file.name,file.checksum]);
   // MySQL DDL implicit commits: keep the applying marker if a statement fails.
   for(const sql of file.statements)await conn.query(sql);
   await conn.execute("UPDATE schema_migrations SET status='applied',applied_at=UTC_TIMESTAMP(3) WHERE version=?",[file.name]);
   console.log('Aplicado: '+file.name);
  }
 }finally{if(locked)await conn.execute('SELECT RELEASE_LOCK(?)',['nordic_migrate_'+name]).catch(()=>{});await conn.end();}
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href)migrate().catch(e=>{console.error('Migração interrompida:',e.message);process.exitCode=1;});

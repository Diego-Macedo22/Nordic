import { readFile, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
export const root=new URL('../',import.meta.url);
export const metadataSQL=`CREATE TABLE IF NOT EXISTS schema_migrations (
  version VARCHAR(100) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
  checksum CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  status ENUM('applying','applied') NOT NULL,
  started_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  applied_at DATETIME(3) NULL
) ENGINE=InnoDB`;
export async function migrationFiles(){
 const names=(await readdir(new URL('migrations/',root))).filter(n=>/^\d{3}_[a-z0-9_]+\.sql$/.test(n)).sort();
 return Promise.all(names.map(async name=>{const sql=await readFile(new URL('migrations/'+name,root),'utf8');return {name,sql,checksum:createHash('sha256').update(sql).digest('hex'),statements:sql.split(/^\s*-- statement-breakpoint\s*$/m).map(s=>s.trim()).filter(Boolean)};}));
}
export async function connectionOptions(){
 const options={host:process.env.DB_HOST||'127.0.0.1',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||'root',password:process.env.DB_PASSWORD||'',charset:'utf8mb4',timezone:'Z',supportBigNumbers:true,bigNumberStrings:true,multipleStatements:false};
 if(process.env.DB_SSL==='true') options.ssl={rejectUnauthorized:true,...(process.env.DB_SSL_CA?{ca:await readFile(process.env.DB_SSL_CA,'utf8')}:{})};
 return options;
}
export function databaseName(){const name=process.env.DB_NAME||'nordic_v05';if(!/^[A-Za-z0-9_]{1,48}$/.test(name))throw new Error('DB_NAME inválido. Use letras, números e sublinhado.');return name;}
